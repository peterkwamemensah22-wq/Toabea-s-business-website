# Toabea's Closet and More — Updated Website

This folder contains the updated customer storefront pages and admin dashboard.

## Included files

- `Toabea.html` — customer storefront entry point
- `shopzone.html` — customer storefront compatibility entry point
- `shopzone-admin.html` — protected admin dashboard

## Implemented improvements

1. Store branding changed to **Toabea's Closet and More**.
2. Completed orders are saved and displayed on the admin Orders page.
3. Inventory is checked during cart use and checkout, reduced by the purchased quantity after a successful order, and products become **Out of Stock** at zero.
4. Admin orders refresh automatically, include status controls, and include WhatsApp notification links.
5. The storefront opens an official WhatsApp message handoff after an order is saved. The recipient number can be changed in Admin → Settings → WhatsApp order notifications.
6. Removed the customer-facing category banners, category navigation link, category browsing button, and category filter buttons. Product category values remain available internally for product management.

## Important deployment note

The supplied project is a static HTML website with browser `localStorage`; it does not include a server, database, or WhatsApp Business API credentials. Therefore, orders and inventory are synchronized between browser tabs on the same device/browser, and WhatsApp uses the official `wa.me` handoff that the store owner confirms in WhatsApp. For silent server-to-server WhatsApp delivery across all customers and devices, connect a backend database and an approved Meta WhatsApp Business Cloud API provider, then move order creation and inventory reservation to that backend.

## How to use

Open `Toabea.html` or `shopzone.html` for the storefront. Open `shopzone-admin.html` for administration. Create the admin account on first launch. Use the Products tab to set stock quantities. Orders made in the same browser profile appear in the admin Orders tab.

The Paystack public key in the original supplied site remains a placeholder and must be replaced with the store's real public key before enabling live card payments.

## Phase 2 backend

An IntelliJ-compatible Java 21 Spring Boot backend is included in `backend/`. It provides MongoDB Atlas persistence, JWT-protected admin APIs, products, categories, customers, orders, atomic inventory processing, inventory history, and a cron-ready MongoDB backup script. Read `backend/README.md` before connecting the storefront or deploying the API. Real Atlas credentials and production secrets are intentionally not included.


## Real-photo 3D hero

The animated hero collage now uses all nine supplied photos. The photos are embedded directly into both storefront HTML files, so the 3D animation still works if someone opens or moves the HTML file without its asset folder. No AI-generated hero imagery is used by this collage.
