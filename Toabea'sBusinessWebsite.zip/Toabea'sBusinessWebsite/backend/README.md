# Toabea's Closet and More — Phase 2 Backend

This folder is an **IntelliJ IDEA-importable Java 21 Spring Boot Maven project**. It replaces browser-only order and inventory storage with a MongoDB-backed API. The code is compiled successfully with Maven in this environment.

## What is implemented

The API includes product and category management, customer records, orders, inventory transactions, atomic stock reservation, protected admin endpoints, BCrypt password hashing, JWT authentication, CORS configuration, actuator health checks, and a one-time environment-driven admin bootstrap. Order creation validates each line item and decrements stock with a server-side atomic `stock >= quantity` check. If a product cannot satisfy the requested quantity, the request fails rather than creating an oversold order. Mongo transactions are enabled for MongoDB Atlas replica sets.

## IntelliJ IDEA setup

Open the `backend` folder in IntelliJ IDEA and choose **Open as Project**. IntelliJ will detect `pom.xml`. Set the project SDK and Maven runner JDK to Java 21. Copy `.env.example` to a private environment configuration, replace the placeholders, and run `ClosetBackendApplication`.

Do not commit a real `.env` file, Atlas connection string, JWT secret, or admin password. Configure those values in IntelliJ Run/Debug Configuration environment variables, a deployment secret manager, or the hosting platform’s secret store.

## MongoDB Atlas setup

Create a production Atlas cluster, database user, network access rule, and database named `toabea_closet`. Use the Atlas SRV URI as `MONGODB_URI`. Atlas must allow the application server’s outbound IP or use an appropriate private networking configuration. The application creates indexes automatically on startup. MongoDB Atlas backup and point-in-time recovery should also be enabled in the Atlas console; the included `scripts/backup-mongodb.sh` provides an additional compressed `mongodump` backup that can be run by cron or a deployment scheduler.

Install the MongoDB Database Tools on the backup host, mark the script executable, and schedule it for example with `0 2 * * * /absolute/path/backend/scripts/backup-mongodb.sh >> /var/log/toabea-backup.log 2>&1`. Store backup archives on a separate encrypted location and periodically test restoration. A backup script is not a substitute for enabling Atlas automated backups.

## Important environment variables

`MONGODB_URI` is the Atlas connection string. `JWT_SECRET` must be a random secret of at least 32 bytes. `BOOTSTRAP_ADMIN_USERNAME` and `BOOTSTRAP_ADMIN_PASSWORD` create the first admin only when that username does not already exist. Change or remove the bootstrap password after the first successful run. `CORS_ALLOWED_ORIGINS` must contain the real HTTPS storefront origin in production.

## Main endpoints

Public endpoints are `GET /api/products/public`, `GET /api/categories/public`, `POST /api/orders`, `POST /api/auth/login`, and `GET /actuator/health`. Admin JWT authentication is required for product CRUD, category CRUD, customer records, order listing/status updates, and inventory history. Send `Authorization: Bearer <token>` after login.

## Production safeguards still required before launch

Connect the storefront checkout to `POST /api/orders` and stop writing orders to browser `localStorage`. Add server-side payment verification before setting an order to paid. Add the approved WhatsApp Business API as a backend notification worker. Configure HTTPS, rate limiting at the edge, structured logs, monitoring, secret rotation, a tested restore procedure, and a production deployment target. The included code is a Phase 2 foundation and should not be called production-live until those deployment and integration steps are completed.
