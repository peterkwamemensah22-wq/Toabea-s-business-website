package com.toabea.closet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ClosetBackendApplication {
  public static void main(String[] args) { SpringApplication.run(ClosetBackendApplication.class, args); }
}
